// cart.js - Shopping cart logic for BrownBee

function addToCart(productId, quantity = 1) {
    if (!isLoggedIn) {
        window.location.href = BASE_URL + 'login.php';
        return;
    }

    const formData = new FormData();
    formData.append('product_id', productId);
    formData.append('quantity', quantity);

    fetch(BASE_URL + 'api/cart.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showToast('Added to your organic basket!', 'success');
            setTimeout(() => {
                window.location.href = BASE_URL + 'store/cart.php';
            }, 800);
        } else {
            showToast(data.message || 'Error adding to basket', 'error');
        }
    })
    .catch(err => {
        console.error('Error:', err);
        showToast('Could not add item. Please try again.', 'error');
    });
}

function updateCartUI(count) {
    const badges = document.querySelectorAll('.cart-count');
    badges.forEach(badge => {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'block' : 'none';
    });
}
