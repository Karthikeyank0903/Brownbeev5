<?php 
require_once __DIR__ . '/../config.php'; 
require_once __DIR__ . '/db.php';

// Fetch Global Settings
$settings_res = $pdo->query("SELECT * FROM settings")->fetchAll();
$site_settings = [];
foreach ($settings_res as $s) {
    $site_settings[$s['setting_key']] = $s['setting_value'];
}
$site_name = $site_settings['site_name'] ?? APP_NAME;
$site_logo = $site_settings['site_logo'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' | ' . APP_NAME : APP_NAME . ' - ' . APP_TAGLINE; ?></title>
    <meta name="description" content="Premium organic food delivered to your doorstep. Pure, natural, and wholesome.">
    
    <!-- CSS Links -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/main.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <script>
        function togglePassword(inputId, icon) {
            const input = document.getElementById(inputId);
            if (!input) return;
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</head>
<body>
    <header>
        <div class="container">
            <div class="nav-top">
                <a href="<?php echo BASE_URL; ?>" class="logo">
                    <div class="logo-icon">
                        <?php if ($site_logo): ?>
                            <img src="<?php echo BASE_URL . $site_logo; ?>" alt="<?php echo e($site_name); ?>" style="width: 100%; height: 100%; object-fit: contain;">
                        <?php else: ?>
                            <i class="fas fa-leaf"></i>
                        <?php endif; ?>
                    </div>
                    <span class="logo-text"><?php echo e($site_name); ?></span>
                </a>
                
                <form action="<?php echo BASE_URL; ?>store/products.php" class="search-bar">
                    <input type="text" name="q" placeholder="Search for organic essentials..." value="<?php echo e($_GET['q'] ?? ''); ?>">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
                
                <div class="nav-icons">
                    <div class="nav-icon-item search-mobile-trigger" style="display: none;">
                        <i class="fas fa-search"></i>
                    </div>
                    
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php 
                            $dashboard_url = BASE_URL . 'account/dashboard.php';
                            if (has_role('admin')) $dashboard_url = BASE_URL . 'admin/dashboard.php';
                            if (has_role('vendor')) $dashboard_url = BASE_URL . 'vendor/dashboard.php';
                        ?>
                        <a href="<?php echo $dashboard_url; ?>" class="nav-icon-item" title="My Account">
                            <i class="far fa-user"></i>
                        </a>
                    <?php else: ?>
                        <a href="<?php echo BASE_URL; ?>login.php" class="nav-icon-item" title="Login">
                            <i class="far fa-user"></i>
                        </a>
                    <?php endif; ?>
                    
                    <a href="<?php echo BASE_URL; ?>account/wishlist.php" class="nav-icon-item" title="Wishlist">
                        <i class="far fa-heart"></i>
                        <span class="badge">0</span>
                    </a>
                    
                    <a href="<?php echo BASE_URL; ?>store/cart.php" class="nav-icon-item" title="Shopping Cart">
                        <i class="fas fa-shopping-basket"></i>
                        <span class="badge cart-count">0</span>
                    </a>
                </div>
            </div>
            
            <nav class="nav-bottom">
                <ul class="nav-links">
                    <li><a href="<?php echo BASE_URL; ?>" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">Home</a></li>
                    
                    <?php if (is_logged_in()): ?>
                        <?php if (has_role('admin')): ?>
                            <li><a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="nav-link">Admin Dashboard</a></li>
                        <?php elseif (has_role('vendor')): ?>
                            <li><a href="<?php echo BASE_URL; ?>vendor/dashboard.php" class="nav-link">Vendor Dashboard</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo BASE_URL; ?>account/dashboard.php" class="nav-link">My Dashboard</a></li>
                        <?php endif; ?>
                    <?php endif; ?>

                    <li><a href="<?php echo BASE_URL; ?>store/products.php" class="nav-link <?php echo strpos($_SERVER['PHP_SELF'], 'products.php') !== false ? 'active' : ''; ?>">Shop All</a></li>
                    <li><a href="<?php echo BASE_URL; ?>store/categories.php" class="nav-link <?php echo strpos($_SERVER['PHP_SELF'], 'categories.php') !== false ? 'active' : ''; ?>">Categories</a></li>
                    
                    <?php if (!is_logged_in() || !has_role('vendor')): ?>
                        <li><a href="<?php echo BASE_URL; ?>vendor-apply.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'vendor-apply.php' ? 'active' : ''; ?>">Sell with Us</a></li>
                    <?php endif; ?>
                </ul>
                
                <div class="nav-promo" style="font-size: 13px; font-weight: 700; color: var(--leaf-green);">
                    <i class="fas fa-bolt" style="margin-right: 5px;"></i> FREE DELIVERY ON ORDERS ABOVE ₹499
                </div>
            </nav>
        </div>
    </header>
    
    <main>
