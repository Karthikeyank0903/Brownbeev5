    </main>

    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <h4 class="logo-text" style="color: var(--white);">BrownBee</h4>
                    <p style="margin-top: 10px;">Your trusted source for 100% certified organic food. From farm to table, naturally.</p>
                    <div class="social-links" style="margin-top: 20px; display: flex; gap: 15px;">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-pinterest"></i></a>
                    </div>
                </div>
                
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="<?php echo BASE_URL; ?>store/products.php">Shop All</a></li>
                        <li><a href="<?php echo BASE_URL; ?>store/categories.php">Categories</a></li>
                        <li><a href="<?php echo BASE_URL; ?>vendor-apply.php">Become a Vendor</a></li>
                        <li><a href="<?php echo BASE_URL; ?>store/cart.php">My Basket</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h4>Customer Care</h4>
                    <ul class="footer-links">
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Track Order</a></li>
                        <li><a href="#">Shipping Policy</a></li>
                        <li><a href="#">Return & Refund</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h4>Newsletter</h4>
                    <p>Subscribe to get updates on organic seasonal harvests.</p>
                    <form style="margin-top: 15px; display: flex; gap: 10px;">
                        <input type="email" placeholder="Your Email" style="padding: 10px; border-radius: 4px; border: none; flex: 1;">
                        <button class="btn btn-primary" style="padding: 10px 15px;">Join</button>
                    </form>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> BrownBee Organic Marketplace. All Rights Reserved.</p>
                <div style="margin-top: 10px;">
                    <img src="https://img.icons8.com/color/48/000000/visa.png" alt="Visa" style="height: 25px; display: inline;">
                    <img src="https://img.icons8.com/color/48/000000/mastercard.png" alt="Mastercard" style="height: 25px; display: inline;">
                    <img src="https://img.icons8.com/color/48/000000/upi.png" alt="UPI" style="height: 25px; display: inline;">
                </div>
            </div>
        </div>
    </footer>

    <!-- JS Links -->
    <script>
        const BASE_URL = '<?php echo BASE_URL; ?>';
        const isLoggedIn = <?php echo is_logged_in() ? 'true' : 'false'; ?>;
    </script>
    <script src="<?php echo BASE_URL; ?>assets/js/main.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/cart.js"></script>
</body>
</html>
