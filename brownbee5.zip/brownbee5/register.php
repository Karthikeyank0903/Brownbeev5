<?php
require_once 'config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (is_logged_in()) {
    redirect(BASE_URL);
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($full_name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } else {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email already registered.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, status) VALUES (?, ?, ?, 'customer', 'active')");
            if ($stmt->execute([$full_name, $email, $hashed_password])) {
                $success = "Registration successful! You can now login.";
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}

$page_title = "Register";
require_once 'includes/header.php';
?>

<div class="container" style="padding: 100px 0;">
    <div style="max-width: 450px; margin: 0 auto; background: var(--white); padding: 40px; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); border: 1px solid var(--gray-light);">
        <div style="text-align: center; margin-bottom: 30px;">
            <h2 style="font-size: 28px;">Create Account</h2>
            <p style="color: var(--gray-dark);">Join our organic community</p>
        </div>

        <?php if ($error): ?>
            <div style="background: #fee2e2; color: #b91c1c; padding: 12px; border-radius: var(--radius-sm); margin-bottom: 20px; font-size: 14px;">
                <i class="fas fa-exclamation-circle" style="margin-right: 8px;"></i> <?php echo e($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div style="background: #dcfce7; color: #15803d; padding: 12px; border-radius: var(--radius-sm); margin-bottom: 20px; font-size: 14px;">
                <i class="fas fa-check-circle" style="margin-right: 8px;"></i> <?php echo e($success); ?> 
                <a href="login.php" style="font-weight: 700; text-decoration: underline;">Login here</a>
            </div>
        <?php endif; ?>

        <form action="register.php" method="POST">
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Full Name</label>
                <input type="text" name="full_name" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="John Doe">
            </div>

            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Email Address</label>
                <input type="email" name="email" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="john@example.com">
            </div>

            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="reg-password" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="Min. 8 characters">
                    <i class="fas fa-eye password-toggle" onclick="togglePassword('reg-password', this)"></i>
                </div>
            </div>

            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Confirm Password</label>
                <div class="password-wrapper">
                    <input type="password" name="confirm_password" id="reg-confirm" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="••••••••">
                    <i class="fas fa-eye password-toggle" onclick="togglePassword('reg-confirm', this)"></i>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; font-size: 16px;">Create Account</button>
        </form>

        <div style="margin-top: 30px; text-align: center; border-top: 1px solid var(--gray-light); padding-top: 20px;">
            <p style="color: var(--gray-dark); font-size: 14px;">Already have an account? <a href="login.php" style="color: var(--amber); font-weight: 600;">Login</a></p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
