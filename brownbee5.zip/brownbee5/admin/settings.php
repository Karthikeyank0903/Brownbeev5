<?php
$page_title = "Platform Settings";
require_once 'includes/admin-header.php';

// Handle Setting Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = trim($_POST['site_name']);
    $commission_rate = trim($_POST['commission_rate']);
    
    // Update basic settings
    $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'site_name'");
    $stmt->execute([$site_name]);
    
    $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'commission_rate'");
    $stmt->execute([$commission_rate]);

    // Handle Logo Upload
    if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] == 0) {
        $upload_dir = '../assets/images/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        
        $ext = pathinfo($_FILES['site_logo']['name'], PATHINFO_EXTENSION);
        $file_name = 'logo_' . time() . '.' . $ext;
        
        if (move_uploaded_file($_FILES['site_logo']['tmp_name'], $upload_dir . $file_name)) {
            // Update DB with new logo path
            $logo_path = 'assets/images/' . $file_name;
            $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'site_logo'");
            $stmt->execute([$logo_path]);
        }
    }
    
    set_flash_message('success', "Settings updated successfully.");
    redirect('settings.php');
}

// Fetch current settings
$settings_raw = $pdo->query("SELECT * FROM settings")->fetchAll();
$settings = [];
foreach ($settings_raw as $s) {
    $settings[$s['setting_key']] = $s['setting_value'];
}
?>

<div class="admin-card" style="max-width: 800px;">
    <div class="admin-card-header">
        <h3>Platform Configuration</h3>
    </div>
    
    <?php $flash = get_flash_message(); if ($flash): ?>
        <div style="padding: 15px 25px; background: #dcfce7; color: #166534; border-bottom: 1px solid #dcfce7;">
            <i class="fas fa-check-circle" style="margin-right: 10px;"></i> <?php echo $flash['message']; ?>
        </div>
    <?php endif; ?>

    <div style="padding: 30px;">
        <form action="settings.php" method="POST" enctype="multipart/form-data">
            <div style="margin-bottom: 30px; display: flex; align-items: center; gap: 40px; background: #fafafa; padding: 25px; border-radius: var(--radius-md); border: 1px solid var(--gray-light);">
                <div>
                    <label style="display: block; margin-bottom: 10px; font-weight: 700;">Platform Logo</label>
                    <div style="width: 120px; height: 120px; background: white; border-radius: 12px; border: 2px dashed var(--gray-medium); display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 15px;">
                        <?php if ($settings['site_logo']): ?>
                            <img src="<?php echo BASE_URL . $settings['site_logo']; ?>" style="max-width: 100%; max-height: 100%;">
                        <?php else: ?>
                            <i class="fas fa-image" style="font-size: 32px; color: var(--gray-medium);"></i>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="flex: 1;">
                    <p style="font-size: 14px; color: var(--gray-dark); margin-bottom: 15px;">Upload a high-quality logo for your store. Recommended size: 200x200px (PNG or SVG preferred).</p>
                    <input type="file" name="site_logo" accept="image/*" style="font-size: 14px;">
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">Site Name</label>
                    <input type="text" name="site_name" value="<?php echo e($settings['site_name']); ?>" style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md);">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">Vendor Commission (%)</label>
                    <input type="number" name="commission_rate" value="<?php echo e($settings['commission_rate']); ?>" style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md);">
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="padding: 12px 30px;">Save All Changes</button>
        </form>
    </div>
</div>

<?php require_once 'includes/admin-header.php'; ?>
