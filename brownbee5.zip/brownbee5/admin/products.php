<?php
$page_title = "Product Catalog";
require_once 'includes/admin-header.php';

// Fetch all products with vendor and category info
$stmt = $pdo->query("
    SELECT p.*, c.name as category_name, vp.store_name 
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    JOIN vendor_profiles vp ON p.vendor_id = vp.user_id 
    ORDER BY p.created_at DESC
");
$products = $stmt->fetchAll();
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h3>Master Product List</h3>
        <div style="display: flex; gap: 10px;">
            <input type="text" placeholder="Search products..." style="padding: 8px; border: 1px solid var(--gray-medium); border-radius: 4px;">
            <button class="btn btn-primary" style="padding: 8px 15px; font-size: 14px;">Filter</button>
        </div>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>Product</th>
                <th>Category</th>
                <th>Vendor</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $p): ?>
            <tr>
                <td>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <div style="width: 40px; height: 40px; background: var(--gray-light); border-radius: 4px;"></div>
                        <div style="font-weight: 600;"><?php echo e($p['name']); ?></div>
                    </div>
                </td>
                <td><?php echo e($p['category_name']); ?></td>
                <td><span style="color: var(--amber); font-weight: 600;"><?php echo e($p['store_name']); ?></span></td>
                <td><?php echo format_currency($p['sale_price'] ?? $p['base_price']); ?></td>
                <td><?php echo $p['stock_quantity']; ?> <?php echo $p['weight_unit']; ?></td>
                <td>
                    <span class="status-pill status-<?php echo $p['status'] == 'published' ? 'approved' : 'pending'; ?>">
                        <?php echo ucfirst($p['status']); ?>
                    </span>
                </td>
                <td>
                    <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px;"><i class="fas fa-eye"></i></button>
                    <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px; color: #b91c1c;"><i class="fas fa-ban"></i></button>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($products)): ?>
            <tr><td colspan="7" style="text-align: center;">No products in catalog</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
