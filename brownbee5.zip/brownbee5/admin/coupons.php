<?php
$page_title = "Coupon Management";
require_once 'includes/admin-header.php';
?>

<div class="admin-card">
    <div style="padding: 100px; text-align: center;">
        <i class="fas fa-ticket-alt" style="font-size: 64px; color: var(--gray-medium); margin-bottom: 30px;"></i>
        <h2>Coupons & Discounts</h2>
        <p style="color: var(--gray-dark); margin-top: 15px;">Manage platform-wide promo codes and seasonal discounts.</p>
        <div style="margin-top: 30px; display: flex; gap: 15px; justify-content: center;">
            <button class="btn btn-primary">Create New Coupon</button>
            <a href="dashboard.php" class="btn btn-outline">Back to Dashboard</a>
        </div>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
