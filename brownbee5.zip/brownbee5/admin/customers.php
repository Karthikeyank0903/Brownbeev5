<?php
$page_title = "Customer Directory";
require_once 'includes/admin-header.php';

$stmt = $pdo->query("SELECT * FROM users WHERE role = 'customer' ORDER BY created_at DESC");
$customers = $stmt->fetchAll();
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h3>Registered Customers</h3>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>Customer Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Status</th>
                <th>Joined Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($customers as $c): ?>
            <tr>
                <td style="font-weight: 600;"><?php echo e($c['full_name']); ?></td>
                <td><?php echo e($c['email']); ?></td>
                <td><?php echo e($c['phone'] ?: 'N/A'); ?></td>
                <td>
                    <span class="status-pill status-<?php echo $c['status']; ?>">
                        <?php echo ucfirst($c['status']); ?>
                    </span>
                </td>
                <td><?php echo date('M d, Y', strtotime($c['created_at'])); ?></td>
                <td>
                    <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px; color: #b91c1c;">Suspend</button>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($customers)): ?>
            <tr><td colspan="6" style="text-align: center;">No customers registered yet</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
