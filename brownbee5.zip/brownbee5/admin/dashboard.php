<?php
$page_title = "Admin Dashboard";
require_once 'includes/admin-header.php';

// Fetch summary stats
$total_vendors = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'vendor'")->fetchColumn();
$pending_vendors = $pdo->query("SELECT COUNT(*) FROM vendor_profiles WHERE status = 'pending'")->fetchColumn();
$total_customers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_orders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$total_revenue = $pdo->query("SELECT SUM(grand_total) FROM orders WHERE payment_status = 'completed'")->fetchColumn() ?: 0;

// Fetch recent vendor applications
$recent_vendors = $pdo->query("
    SELECT u.full_name, u.email, vp.store_name, vp.status, u.created_at 
    FROM users u 
    JOIN vendor_profiles vp ON u.id = vp.user_id 
    ORDER BY u.created_at DESC LIMIT 5
")->fetchAll();

// Fetch recent orders
$recent_orders = $pdo->query("
    SELECT o.*, u.full_name as customer_name 
    FROM orders o 
    JOIN users u ON o.customer_id = u.id 
    ORDER BY o.created_at DESC LIMIT 5
")->fetchAll();
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon" style="background: #e0f2fe; color: #0369a1;"><i class="fas fa-wallet"></i></div>
        <div class="stat-info">
            <h3><?php echo format_currency($total_revenue); ?></h3>
            <p>Total Revenue</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background: #dcfce7; color: #15803d;"><i class="fas fa-shopping-bag"></i></div>
        <div class="stat-info">
            <h3><?php echo $total_orders; ?></h3>
            <p>Total Orders</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background: #fef3c7; color: #92400e;"><i class="fas fa-store"></i></div>
        <div class="stat-info">
            <h3><?php echo $total_vendors; ?></h3>
            <p>Total Vendors</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background: #f1f5f9; color: #475569;"><i class="fas fa-users"></i></div>
        <div class="stat-info">
            <h3><?php echo $total_customers; ?></h3>
            <p>Total Customers</p>
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
    <!-- Recent Vendor Applications -->
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>Vendor Applications</h3>
            <a href="vendors.php" class="btn btn-outline" style="padding: 5px 15px; font-size: 12px;">View All</a>
        </div>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Store Name</th>
                    <th>Vendor</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_vendors as $vendor): ?>
                <tr>
                    <td><?php echo e($vendor['store_name']); ?></td>
                    <td><?php echo e($vendor['full_name']); ?></td>
                    <td>
                        <span class="status-pill status-<?php echo $vendor['status']; ?>">
                            <?php echo ucfirst($vendor['status']); ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recent_vendors)): ?>
                <tr><td colspan="3" style="text-align: center;">No applications found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Recent Orders -->
    <div class="admin-card">
        <div class="admin-card-header">
            <h3>Recent Orders</h3>
            <a href="orders.php" class="btn btn-outline" style="padding: 5px 15px; font-size: 12px;">View All</a>
        </div>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_orders as $order): ?>
                <tr>
                    <td>#<?php echo $order['id']; ?></td>
                    <td><?php echo e($order['customer_name']); ?></td>
                    <td><?php echo format_currency($order['grand_total']); ?></td>
                    <td>
                        <span class="status-pill status-<?php echo $order['order_status']; ?>">
                            <?php echo ucfirst($order['order_status']); ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recent_orders)): ?>
                <tr><td colspan="4" style="text-align: center;">No orders yet</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
