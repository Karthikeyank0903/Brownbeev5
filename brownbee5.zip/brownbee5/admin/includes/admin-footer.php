        </div>
    </main>
    
    <!-- Admin JS -->
    <script src="<?php echo BASE_URL; ?>assets/js/admin-charts.js"></script>
</body>
</html>
