<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

// Auth Check
if (!is_logged_in() || !has_role('admin')) {
    redirect(BASE_URL . 'login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' | Admin' : 'BrownBee Admin'; ?></title>
    
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/main.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="admin-body">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="logo">
                <div class="logo-icon" style="width: 32px; height: 32px; background: var(--amber); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white; font-size: 14px;">
                    <i class="fas fa-leaf"></i>
                </div>
                <span class="logo-text" style="color: var(--white); font-size: 20px;">BrownBee</span>
            </a>
        </div>
        
        <nav class="admin-nav">
            <a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="admin-nav-item active">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="<?php echo BASE_URL; ?>admin/vendors.php" class="admin-nav-item">
                <i class="fas fa-store"></i> Vendor Management
            </a>
            <a href="<?php echo BASE_URL; ?>admin/categories.php" class="admin-nav-item">
                <i class="fas fa-tags"></i> Categories
            </a>
            <a href="<?php echo BASE_URL; ?>admin/products.php" class="admin-nav-item">
                <i class="fas fa-box"></i> All Products
            </a>
            <a href="<?php echo BASE_URL; ?>admin/orders.php" class="admin-nav-item">
                <i class="fas fa-shopping-cart"></i> All Orders
            </a>
            <a href="<?php echo BASE_URL; ?>admin/customers.php" class="admin-nav-item">
                <i class="fas fa-users"></i> Customers
            </a>
            <a href="<?php echo BASE_URL; ?>admin/banners.php" class="admin-nav-item">
                <i class="fas fa-image"></i> Banners & Ads
            </a>
            <a href="<?php echo BASE_URL; ?>admin/coupons.php" class="admin-nav-item">
                <i class="fas fa-ticket-alt"></i> Coupons
            </a>
            <a href="<?php echo BASE_URL; ?>admin/payouts.php" class="admin-nav-item">
                <i class="fas fa-money-bill-wave"></i> Payouts
            </a>
            <a href="<?php echo BASE_URL; ?>admin/settings.php" class="admin-nav-item">
                <i class="fas fa-cog"></i> Settings
            </a>
        </nav>
        
        <div class="admin-sidebar-footer" style="padding: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
            <a href="<?php echo BASE_URL; ?>logout.php" class="admin-nav-item" style="padding: 0;">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </aside>

    <main class="admin-main">
        <header class="admin-header">
            <div class="admin-header-left">
                <h2 style="font-size: 20px; font-family: var(--body-font);"><?php echo $page_title ?? 'Dashboard'; ?></h2>
            </div>
            <div class="admin-header-right" style="display: flex; gap: 20px; align-items: center;">
                <div class="admin-user" style="display: flex; gap: 10px; align-items: center;">
                    <div style="text-align: right;">
                        <p style="font-weight: 600; font-size: 14px;"><?php echo e($_SESSION['full_name']); ?></p>
                        <p style="font-size: 12px; color: var(--gray-dark);">Super Admin</p>
                    </div>
                    <div style="width: 40px; height: 40px; border-radius: var(--radius-full); background: var(--cream); display: flex; align-items: center; justify-content: center; color: var(--brown); font-weight: 700;">
                        SA
                    </div>
                </div>
            </div>
        </header>
        <div class="admin-content">
