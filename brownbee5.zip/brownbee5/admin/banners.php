<?php
$page_title = "Admin Tool";
require_once 'includes/admin-header.php';
?>

<div class="admin-card">
    <div style="padding: 100px; text-align: center;">
        <i class="fas fa-tools" style="font-size: 64px; color: var(--gray-medium); margin-bottom: 30px;"></i>
        <h2>Feature Coming Soon</h2>
        <p style="color: var(--gray-dark); margin-top: 15px;">We are currently working on this administrative tool. Check back soon!</p>
        <a href="dashboard.php" class="btn btn-primary" style="margin-top: 30px;">Back to Dashboard</a>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
