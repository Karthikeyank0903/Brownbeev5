<?php
$page_title = "Category Management";
require_once 'includes/admin-header.php';

// Handle Add/Delete (Simplified)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $name = trim($_POST['name']);
    $slug = slugify($name);
    $description = trim($_POST['description']);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)");
        $stmt->execute([$name, $slug, $description]);
        set_flash_message('success', "Category added successfully.");
    } catch (Exception $e) {
        set_flash_message('error', "Error: " . $e->getMessage());
    }
    redirect('categories.php');
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
?>

<div style="display: grid; grid-template-columns: 350px 1fr; gap: 30px;">
    <!-- Add Category Form -->
    <div class="admin-card">
        <div class="admin-card-header"><h3>Add New Category</h3></div>
        <div style="padding: 25px;">
            <form action="categories.php" method="POST">
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">Category Name</label>
                    <input type="text" name="name" required style="width: 100%; padding: 10px; border: 1px solid var(--gray-medium); border-radius: var(--radius-sm);">
                </div>
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">Description</label>
                    <textarea name="description" rows="4" style="width: 100%; padding: 10px; border: 1px solid var(--gray-medium); border-radius: var(--radius-sm);"></textarea>
                </div>
                <button type="submit" name="add_category" class="btn btn-primary" style="width: 100%;">Create Category</button>
            </form>
        </div>
    </div>

    <!-- Categories List -->
    <div class="admin-card">
        <div class="admin-card-header"><h3>Existing Categories</h3></div>
        
        <?php $flash = get_flash_message(); if ($flash): ?>
            <div style="padding: 15px 25px; background: <?php echo $flash['type'] == 'success' ? '#dcfce7' : '#fee2e2'; ?>; color: <?php echo $flash['type'] == 'success' ? '#166534' : '#991b1b'; ?>;">
                <?php echo $flash['message']; ?>
            </div>
        <?php endif; ?>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td style="font-weight: 600;"><?php echo e($cat['name']); ?></td>
                    <td><code><?php echo e($cat['slug']); ?></code></td>
                    <td>
                        <span class="status-pill status-<?php echo $cat['status']; ?>">
                            <?php echo ucfirst($cat['status']); ?>
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px;"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px; color: #b91c1c;"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
