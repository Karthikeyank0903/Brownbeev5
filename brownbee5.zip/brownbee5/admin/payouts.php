<?php
$page_title = "Vendor Payouts";
require_once 'includes/admin-header.php';

// Fetch pending payouts
$stmt = $pdo->query("
    SELECT p.*, vp.store_name 
    FROM payouts p 
    JOIN vendor_profiles vp ON p.vendor_id = vp.user_id 
    ORDER BY p.created_at DESC
");
$payouts = $stmt->fetchAll();
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h3>Payout Requests</h3>
    </div>
    
    <table class="admin-table">
        <thead>
            <tr>
                <th>Vendor</th>
                <th>Amount</th>
                <th>Request Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($payouts as $p): ?>
            <tr>
                <td><?php echo e($p['store_name']); ?></td>
                <td style="font-weight: 700;"><?php echo format_currency($p['amount']); ?></td>
                <td><?php echo date('M d, Y', strtotime($p['created_at'])); ?></td>
                <td>
                    <span class="status-pill status-<?php echo $p['status']; ?>">
                        <?php echo ucfirst($p['status']); ?>
                    </span>
                </td>
                <td>
                    <?php if ($p['status'] == 'pending'): ?>
                        <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;">Process Payout</button>
                    <?php else: ?>
                        <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px;" disabled>Processed</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($payouts)): ?>
            <tr><td colspan="5" style="text-align: center; padding: 50px;">No payout requests found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
