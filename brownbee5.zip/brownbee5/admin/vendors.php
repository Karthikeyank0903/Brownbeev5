<?php
$page_title = "Vendor Management";
require_once 'includes/admin-header.php';

// Handle Vendor Approval/Rejection
if (isset($_GET['action']) && isset($_GET['id'])) {
    $vendor_id = $_GET['id'];
    $action = $_GET['action'];
    $status = ($action === 'approve') ? 'approved' : 'rejected';
    $user_status = ($action === 'approve') ? 'active' : 'inactive';

    try {
        $pdo->beginTransaction();
        
        // Update vendor profile
        $stmt = $pdo->prepare("UPDATE vendor_profiles SET status = ? WHERE user_id = ?");
        $stmt->execute([$status, $vendor_id]);
        
        // Update user status
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->execute([$user_status, $vendor_id]);
        
        $pdo->commit();
        set_flash_message('success', "Vendor application " . $status . " successfully.");
    } catch (Exception $e) {
        $pdo->rollBack();
        set_flash_message('error', "Action failed: " . $e->getMessage());
    }
    redirect('vendors.php');
}

// Fetch all vendors
$stmt = $pdo->query("
    SELECT u.id, u.full_name, u.email, u.phone, vp.store_name, vp.status, u.created_at 
    FROM users u 
    JOIN vendor_profiles vp ON u.id = vp.user_id 
    ORDER BY u.created_at DESC
");
$vendors = $stmt->fetchAll();
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h3>Vendor Applications & Registered Sellers</h3>
    </div>
    
    <?php $flash = get_flash_message(); if ($flash): ?>
        <div style="padding: 15px 25px; background: <?php echo $flash['type'] == 'success' ? '#dcfce7' : '#fee2e2'; ?>; color: <?php echo $flash['type'] == 'success' ? '#166534' : '#991b1b'; ?>;">
            <?php echo $flash['message']; ?>
        </div>
    <?php endif; ?>

    <table class="admin-table">
        <thead>
            <tr>
                <th>Vendor Info</th>
                <th>Store Details</th>
                <th>Status</th>
                <th>Joined Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($vendors as $vendor): ?>
            <tr>
                <td>
                    <div style="font-weight: 600;"><?php echo e($vendor['full_name']); ?></div>
                    <div style="font-size: 12px; color: var(--gray-dark);"><?php echo e($vendor['email']); ?></div>
                </td>
                <td><?php echo e($vendor['store_name']); ?></td>
                <td>
                    <span class="status-pill status-<?php echo $vendor['status']; ?>">
                        <?php echo ucfirst($vendor['status']); ?>
                    </span>
                </td>
                <td><?php echo date('M d, Y', strtotime($vendor['created_at'])); ?></td>
                <td>
                    <?php if ($vendor['status'] === 'pending'): ?>
                        <a href="vendors.php?action=approve&id=<?php echo $vendor['id']; ?>" class="btn btn-primary" style="padding: 5px 10px; font-size: 12px; background: var(--leaf-green);">Approve</a>
                        <a href="vendors.php?action=reject&id=<?php echo $vendor['id']; ?>" class="btn btn-outline" style="padding: 5px 10px; font-size: 12px; border-color: #b91c1c; color: #b91c1c;">Reject</a>
                    <?php else: ?>
                        <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px;">View Details</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($vendors)): ?>
            <tr><td colspan="5" style="text-align: center;">No vendors found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
