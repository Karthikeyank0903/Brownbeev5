<?php
$page_title = "Global Orders";
require_once 'includes/admin-header.php';

$stmt = $pdo->query("
    SELECT o.*, u.full_name as customer_name 
    FROM orders o 
    JOIN users u ON o.customer_id = u.id 
    ORDER BY o.created_at DESC
");
$orders = $stmt->fetchAll();
?>

<div class="admin-card">
    <div class="admin-card-header">
        <h3>Customer Orders</h3>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Total</th>
                <th>Payment</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $o): ?>
            <tr>
                <td>#<?php echo $o['id']; ?></td>
                <td><?php echo e($o['customer_name']); ?></td>
                <td style="font-weight: 700;"><?php echo format_currency($o['grand_total']); ?></td>
                <td>
                    <span style="font-size: 12px;"><?php echo $o['payment_method']; ?></span>
                    <div style="font-size: 10px; color: <?php echo $o['payment_status'] == 'completed' ? 'green' : 'orange'; ?>;"><?php echo strtoupper($o['payment_status']); ?></div>
                </td>
                <td>
                    <span class="status-pill status-<?php echo $o['order_status']; ?>">
                        <?php echo ucfirst($o['order_status']); ?>
                    </span>
                </td>
                <td><?php echo date('M d, Y', strtotime($o['created_at'])); ?></td>
                <td>
                    <button class="btn btn-outline" style="padding: 5px 10px; font-size: 12px;">Manage</button>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($orders)): ?>
            <tr><td colspan="7" style="text-align: center;">No orders found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once 'includes/admin-footer.php'; ?>
