<?php
// config.php - Main configuration file for BrownBee
ob_start();

// Load .env file
function loadEnv($path) {
    if (!file_exists($path)) {
        return false;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        list($name, $value) = explode('=', $line, 2);
        $_ENV[trim($name)] = trim($value);
        putenv(trim($name) . "=" . trim($value));
    }
    return true;
}

loadEnv(__DIR__ . '/.env');

// Database Configuration
define('DB_HOST', $_ENV['DB_HOST'] ?? 'localhost');
define('DB_NAME', $_ENV['DB_NAME'] ?? 'brownbee_db');
define('DB_USER', $_ENV['DB_USER'] ?? 'root');
define('DB_PASS', $_ENV['DB_PASS'] ?? '');

// App Constants
define('APP_NAME', 'BrownBee');
define('APP_TAGLINE', 'Pure. Natural. Delivered.');
define('BASE_URL', 'https://brownbee.in/demo/'); // Production URL

// Admin Credentials (from .env)
define('ADMIN_EMAIL', $_ENV['ADMIN_EMAIL'] ?? 'admin@brownbee.com');
define('ADMIN_PASS', $_ENV['ADMIN_PASS'] ?? 'Admin@123');

// Session Config
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Error Reporting (Development Mode)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('UTC');
?>
