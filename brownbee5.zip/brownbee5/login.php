<?php
require_once 'config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (is_logged_in()) {
    if (has_role('admin')) redirect(BASE_URL . 'admin/dashboard.php');
    if (has_role('vendor')) redirect(BASE_URL . 'vendor/dashboard.php');
    redirect(BASE_URL . 'account/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "Please enter both email and password.";
    } else {
        // Check if it's the Super Admin from .env
        if ($email === ADMIN_EMAIL && $password === ADMIN_PASS) {
            // Ensure admin exists in DB (sanity check)
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_role'] = 'admin';
                $_SESSION['full_name'] = $user['full_name'];
                redirect(BASE_URL . 'admin/dashboard.php');
            }
        }

        // Regular login
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['status'] === 'inactive') {
                $error = "Your account is inactive. Please contact support.";
            } elseif ($user['status'] === 'pending' && $user['role'] === 'vendor') {
                $error = "Your vendor application is still pending approval.";
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['full_name'] = $user['full_name'];

                if ($user['role'] === 'admin') redirect(BASE_URL . 'admin/dashboard.php');
                if ($user['role'] === 'vendor') redirect(BASE_URL . 'vendor/dashboard.php');
                redirect(BASE_URL . 'account/dashboard.php');
            }
        } else {
            $error = "Invalid email or password.";
        }
    }
}

$page_title = "Login";
require_once 'includes/header.php';
?>

<div class="container" style="padding: 100px 0;">
    <div style="max-width: 450px; margin: 0 auto; background: var(--white); padding: 40px; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); border: 1px solid var(--gray-light);">
        <div style="text-align: center; margin-bottom: 30px;">
            <h2 style="font-size: 28px;">Welcome Back</h2>
            <p style="color: var(--gray-dark);">Login to your BrownBee account</p>
        </div>

        <?php if ($error): ?>
            <div style="background: #fee2e2; color: #b91c1c; padding: 12px; border-radius: var(--radius-sm); margin-bottom: 20px; font-size: 14px;">
                <i class="fas fa-exclamation-circle" style="margin-right: 8px;"></i> <?php echo e($error); ?>
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Email Address</label>
                <input type="email" name="email" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="john@example.com">
            </div>

            <div style="margin-bottom: 25px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <label style="font-weight: 600; color: var(--brown);">Password</label>
                    <a href="#" style="font-size: 13px; color: var(--amber);">Forgot Password?</a>
                </div>
                <div class="password-wrapper">
                    <input type="password" name="password" id="login-password" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="••••••••">
                    <i class="fas fa-eye password-toggle" onclick="togglePassword('login-password', this)"></i>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; font-size: 16px;">Login to Account</button>
        </form>

        <div style="margin-top: 30px; text-align: center; border-top: 1px solid var(--gray-light); padding-top: 20px;">
            <p style="color: var(--gray-dark); font-size: 14px;">Don't have an account? <a href="register.php" style="color: var(--amber); font-weight: 600;">Sign Up</a></p>
            <p style="margin-top: 10px; font-size: 14px;">Want to sell products? <a href="vendor-apply.php" style="color: var(--leaf-green); font-weight: 600;">Become a Vendor</a></p>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
