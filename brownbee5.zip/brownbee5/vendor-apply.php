<?php
require_once 'config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (is_logged_in() && has_role('vendor')) {
    redirect(BASE_URL . 'vendor/dashboard.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $store_name = trim($_POST['store_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $phone = trim($_POST['phone'] ?? '');

    if (empty($full_name) || empty($email) || empty($store_name) || empty($password)) {
        $error = "Essential fields are required.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email already registered.";
        } else {
            try {
                $pdo->beginTransaction();

                $hashed_password = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
                $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, phone, role, status) VALUES (?, ?, ?, ?, 'vendor', 'pending')");
                $stmt->execute([$full_name, $email, $hashed_password, $phone]);
                $user_id = $pdo->lastInsertId();

                $stmt = $pdo->prepare("INSERT INTO vendor_profiles (user_id, store_name, status) VALUES (?, ?, 'pending')");
                $stmt->execute([$user_id, $store_name]);

                $pdo->commit();
                $success = "Application submitted successfully! Our team will review your application and get back to you.";
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Submission failed: " . $e->getMessage();
            }
        }
    }
}

$page_title = "Apply as Vendor";
require_once 'includes/header.php';
?>

<div class="container" style="padding: 100px 0;">
    <div style="display: flex; gap: 50px; align-items: center;">
        <div style="flex: 1;">
            <span style="color: var(--leaf-green); font-weight: 700; text-transform: uppercase; letter-spacing: 2px;">Partner with us</span>
            <h1 style="font-size: 42px; margin: 15px 0;">Grow Your Organic Business with BrownBee</h1>
            <p style="font-size: 18px; color: var(--gray-dark); margin-bottom: 30px;">Join the largest marketplace for organic and natural products. Reach thousands of health-conscious customers and grow your brand.</p>
            
            <ul style="margin-bottom: 40px;">
                <li style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center;">
                    <i class="fas fa-check-circle" style="color: var(--leaf-green);"></i>
                    <span>Low commission rates (only 10%)</span>
                </li>
                <li style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center;">
                    <i class="fas fa-check-circle" style="color: var(--leaf-green);"></i>
                    <span>Dedicated vendor dashboard</span>
                </li>
                <li style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center;">
                    <i class="fas fa-check-circle" style="color: var(--leaf-green);"></i>
                    <span>Secure & timely payments</span>
                </li>
                <li style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center;">
                    <i class="fas fa-check-circle" style="color: var(--leaf-green);"></i>
                    <span>Product promotion assistance</span>
                </li>
            </ul>
        </div>

        <div style="flex: 1; background: var(--white); padding: 40px; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg); border: 1px solid var(--gray-light);">
            <h2 style="margin-bottom: 25px; text-align: center;">Vendor Application</h2>

            <?php if ($error): ?>
                <div style="background: #fee2e2; color: #b91c1c; padding: 12px; border-radius: var(--radius-sm); margin-bottom: 20px; font-size: 14px;">
                    <i class="fas fa-exclamation-circle" style="margin-right: 8px;"></i> <?php echo e($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div style="background: #dcfce7; color: #15803d; padding: 12px; border-radius: var(--radius-sm); margin-bottom: 20px; font-size: 14px;">
                    <i class="fas fa-check-circle" style="margin-right: 8px;"></i> <?php echo e($success); ?>
                </div>
            <?php else: ?>
                <form action="vendor-apply.php" method="POST">
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Full Name</label>
                        <input type="text" name="full_name" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="Full Name">
                    </div>

                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Email Address</label>
                        <input type="email" name="email" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="email@example.com">
                    </div>

                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Store Name</label>
                        <input type="text" name="store_name" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="e.g. Green Valley Farms">
                    </div>

                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Phone Number</label>
                        <input type="text" name="phone" style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="+1 234 567 890">
                    </div>

                    <div style="margin-bottom: 25px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: var(--brown);">Password</label>
                        <div class="password-wrapper">
                            <input type="password" name="password" id="vendor-password" required style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); outline: none;" placeholder="••••••••">
                            <i class="fas fa-eye password-toggle" onclick="togglePassword('vendor-password', this)"></i>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-secondary" style="width: 100%; font-size: 16px;">Submit Application</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
