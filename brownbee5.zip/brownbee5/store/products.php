<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$page_title = "Shop Organic Products";
require_once '../includes/header.php';

$category_filter = $_GET['category'] ?? '';
$search_query = $_GET['q'] ?? '';

$sql = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.status = 'published'";
$params = [];

if ($category_filter) {
    $sql .= " AND c.slug = ?";
    $params[] = $category_filter;
}

if ($search_query) {
    $sql .= " AND (p.name LIKE ? OR p.description LIKE ?)";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
}

$sql .= " ORDER BY p.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories WHERE status = 'active'")->fetchAll();
?>

<div class="container" style="padding: 40px 0;">
    <div style="display: flex; gap: 40px;">
        <!-- Sidebar Filters -->
        <aside style="width: 250px; flex-shrink: 0;">
            <div style="margin-bottom: 30px;">
                <h3 style="margin-bottom: 20px; font-size: 20px;">Categories</h3>
                <ul class="footer-links" style="color: var(--black);">
                    <li><a href="products.php" style="font-weight: <?php echo !$category_filter ? '700' : '400'; ?>">All Products</a></li>
                    <?php foreach ($categories as $cat): ?>
                    <li>
                        <a href="products.php?category=<?php echo $cat['slug']; ?>" 
                           style="font-weight: <?php echo $category_filter === $cat['slug'] ? '700' : '400'; ?>">
                            <?php echo e($cat['name']); ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div style="margin-bottom: 30px;">
                <h3 style="margin-bottom: 20px; font-size: 20px;">Dietary Pref.</h3>
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    <label style="display: flex; gap: 10px; cursor: pointer;"><input type="checkbox"> Vegan</label>
                    <label style="display: flex; gap: 10px; cursor: pointer;"><input type="checkbox"> Gluten-Free</label>
                    <label style="display: flex; gap: 10px; cursor: pointer;"><input type="checkbox"> Raw</label>
                </div>
            </div>
        </aside>

        <!-- Product Listing -->
        <div style="flex: 1;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                <p style="color: var(--gray-dark);"><?php echo count($products); ?> products found</p>
                <select style="padding: 8px; border-radius: 4px; border: 1px solid var(--gray-medium);">
                    <option>Sort by: Newest</option>
                    <option>Price: Low to High</option>
                    <option>Price: High to Low</option>
                </select>
            </div>

            <?php if (empty($products)): ?>
                <div style="text-align: center; padding: 60px; background: var(--gray-light); border-radius: var(--radius-md);">
                    <i class="fas fa-search" style="font-size: 40px; color: var(--gray-medium); margin-bottom: 20px;"></i>
                    <h3>No products found</h3>
                    <p>Try adjusting your filters or search query.</p>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <span class="product-badge">Organic</span>
                        <div class="product-wishlist"><i class="far fa-heart"></i></div>
                        <div class="product-image">
                            <img src="<?php echo BASE_URL; ?>uploads/products/placeholder.jpg" alt="<?php echo e($product['name']); ?>">
                        </div>
                        <div class="product-info">
                            <span class="product-cat"><?php echo e($product['category_name']); ?></span>
                            <a href="product.php?slug=<?php echo $product['slug']; ?>" class="product-name"><?php echo e($product['name']); ?></a>
                            <div class="product-price">
                                <span class="price-current"><?php echo format_currency($product['sale_price'] ?? $product['base_price']); ?></span>
                                <?php if ($product['sale_price']): ?>
                                    <span class="price-old"><?php echo format_currency($product['base_price']); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="product-actions">
                                <button class="btn btn-primary" style="flex: 1; padding: 10px;" onclick="addToCart(<?php echo $product['id']; ?>)">
                                    <i class="fas fa-cart-plus" style="margin-right: 8px;"></i> Add to Basket
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
