<?php
require_once '../config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

$page_title = "My Organic Basket";
require_once '../includes/header.php';

$cart = $_SESSION['cart'] ?? [];
$cart_items = [];
$total = 0;

if (!empty($cart)) {
    $ids = array_keys($cart);
    $placeholders = str_repeat('?,', count($ids) - 1) . '?';
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll();

    foreach ($products as $p) {
        $qty = $cart[$p['id']];
        $subtotal = ($p['sale_price'] ?? $p['base_price']) * $qty;
        $total += $subtotal;
        $cart_items[] = [
            'id' => $p['id'],
            'name' => $p['name'],
            'price' => $p['sale_price'] ?? $p['base_price'],
            'qty' => $qty,
            'subtotal' => $subtotal,
            'image' => 'uploads/products/placeholder.jpg'
        ];
    }
}
?>

<div class="container" style="padding: 60px 0;">
    <h2 style="font-size: 32px; margin-bottom: 40px; border-bottom: 2px solid var(--cream); padding-bottom: 20px;">My Shopping Basket</h2>

    <?php if (empty($cart_items)): ?>
        <div style="text-align: center; max-width: 600px; margin: 0 auto; background: var(--cream); padding: 50px; border-radius: var(--radius-lg);">
            <i class="fas fa-shopping-basket" style="font-size: 64px; color: var(--amber); margin-bottom: 25px;"></i>
            <h2 style="margin-bottom: 15px;">Your basket is currently empty</h2>
            <p style="color: var(--gray-dark); margin-bottom: 30px;">Looks like you haven't added any organic goodness yet.</p>
            <a href="products.php" class="btn btn-primary">Browse Harvests</a>
        </div>
    <?php else: ?>
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 40px; align-items: start;">
            <!-- Cart Items -->
            <div style="background: var(--white); border-radius: var(--radius-lg); box-shadow: var(--shadow-sm); border: 1px solid var(--gray-light); overflow: hidden;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: var(--gray-light); text-align: left;">
                            <th style="padding: 20px;">Product</th>
                            <th style="padding: 20px;">Price</th>
                            <th style="padding: 20px;">Quantity</th>
                            <th style="padding: 20px;">Subtotal</th>
                            <th style="padding: 20px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): ?>
                        <tr style="border-bottom: 1px solid var(--gray-light);">
                            <td style="padding: 20px; display: flex; align-items: center; gap: 15px;">
                                <div style="width: 60px; height: 60px; background: var(--gray-light); border-radius: 8px; overflow: hidden;">
                                    <img src="<?php echo BASE_URL . $item['image']; ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                </div>
                                <span style="font-weight: 700; color: var(--brown);"><?php echo e($item['name']); ?></span>
                            </td>
                            <td style="padding: 20px;"><?php echo format_currency($item['price']); ?></td>
                            <td style="padding: 20px;">
                                <div style="display: flex; align-items: center; gap: 10px; border: 1px solid var(--gray-medium); border-radius: var(--radius-sm); width: fit-content; padding: 5px 10px;">
                                    <button style="border: none; background: none; cursor: pointer;"><i class="fas fa-minus" style="font-size: 10px;"></i></button>
                                    <span style="font-weight: 700;"><?php echo $item['qty']; ?></span>
                                    <button style="border: none; background: none; cursor: pointer;"><i class="fas fa-plus" style="font-size: 10px;"></i></button>
                                </div>
                            </td>
                            <td style="padding: 20px; font-weight: 700; color: var(--leaf-green);"><?php echo format_currency($item['subtotal']); ?></td>
                            <td style="padding: 20px; text-align: right;">
                                <a href="#" style="color: #b91c1c;"><i class="fas fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Summary -->
            <div style="background: var(--brown); color: var(--white); padding: 40px; border-radius: var(--radius-lg); position: sticky; top: 120px;">
                <h3 style="color: var(--white); margin-bottom: 25px; font-family: var(--body-font);">Order Summary</h3>
                <div style="display: flex; justify-content: space-between; margin-bottom: 15px; opacity: 0.8;">
                    <span>Subtotal</span>
                    <span><?php echo format_currency($total); ?></span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 15px; opacity: 0.8;">
                    <span>Shipping</span>
                    <span>Free</span>
                </div>
                <div style="margin-top: 25px; padding-top: 25px; border-top: 1px solid rgba(255,255,255,0.1); display: flex; justify-content: space-between; font-size: 20px; font-weight: 700;">
                    <span>Total</span>
                    <span style="color: var(--amber);"><?php echo format_currency($total); ?></span>
                </div>
                
                <a href="checkout.php" class="btn btn-secondary" style="width: 100%; margin-top: 30px; padding: 18px;">Proceed to Checkout</a>
                <a href="products.php" style="display: block; text-align: center; margin-top: 20px; font-size: 14px; opacity: 0.7;">Continue Shopping</a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
