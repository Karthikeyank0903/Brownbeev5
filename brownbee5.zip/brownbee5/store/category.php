<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$slug = $_GET['slug'] ?? '';

if (!$slug) {
    redirect('products.php');
}

// Fetch category details
$stmt = $pdo->prepare("SELECT * FROM categories WHERE slug = ? AND status = 'active'");
$stmt->execute([$slug]);
$category = $stmt->fetch();

if (!$category) {
    redirect('products.php');
}

$page_title = $category['name'];
require_once '../includes/header.php';

// Fetch products in this category
$stmt = $pdo->prepare("
    SELECT p.*, c.name as category_name 
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    WHERE c.slug = ? AND p.status = 'published'
");
$stmt->execute([$slug]);
$products = $stmt->fetchAll();
?>

<div class="container" style="padding: 60px 0;">
    <div style="text-align: center; margin-bottom: 50px;">
        <span style="color: var(--leaf-green); font-weight: 700; text-transform: uppercase; letter-spacing: 2px;">Category</span>
        <h1 style="font-size: 42px; margin-top: 10px;"><?php echo e($category['name']); ?></h1>
        <?php if ($category['description']): ?>
            <p style="color: var(--gray-dark); max-width: 700px; margin: 15px auto; font-size: 18px;">
                <?php echo e($category['description']); ?>
            </p>
        <?php endif; ?>
    </div>

    <?php if (empty($products)): ?>
        <div style="text-align: center; padding: 60px; background: var(--gray-light); border-radius: var(--radius-md);">
            <i class="fas fa-seedling" style="font-size: 48px; color: var(--gray-medium); margin-bottom: 20px;"></i>
            <h3>No products in this category yet</h3>
            <p>Our farmers are busy harvesting. Check back soon!</p>
            <a href="products.php" class="btn btn-secondary" style="margin-top: 20px;">View All Products</a>
        </div>
    <?php else: ?>
        <div class="products-grid">
            <?php foreach ($products as $product): ?>
            <div class="product-card">
                <span class="product-badge">Organic</span>
                <div class="product-image">
                    <img src="<?php echo BASE_URL; ?>uploads/products/placeholder.jpg" alt="<?php echo e($product['name']); ?>">
                </div>
                <div class="product-info">
                    <span class="product-cat"><?php echo e($product['category_name']); ?></span>
                    <a href="product.php?slug=<?php echo $product['slug']; ?>" class="product-name"><?php echo e($product['name']); ?></a>
                    <div class="product-price">
                        <span class="price-current"><?php echo format_currency($product['sale_price'] ?? $product['base_price']); ?></span>
                    </div>
                    <div class="product-actions">
                        <button class="btn btn-primary" style="flex: 1; padding: 10px;" onclick="addToCart(<?php echo $product['id']; ?>)">
                            Add to Basket
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
