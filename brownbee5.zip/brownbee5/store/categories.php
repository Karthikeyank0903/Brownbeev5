<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$page_title = "Product Categories";
require_once '../includes/header.php';

$categories = $pdo->query("SELECT * FROM categories WHERE status = 'active'")->fetchAll();
?>

<div class="container" style="padding: 60px 0;">
    <div class="section-title">
        <h2>Our Organic Collection</h2>
        <p>Choose from our carefully curated categories of natural goodness</p>
    </div>

    <div class="categories-grid" style="grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 30px;">
        <?php foreach ($categories as $cat): ?>
        <a href="products.php?category=<?php echo $cat['slug']; ?>" class="category-card" style="padding: 40px;">
            <div style="font-size: 50px; color: var(--amber); margin-bottom: 20px;">
                <i class="fas fa-shopping-basket"></i>
            </div>
            <h3 style="font-size: 24px; margin-bottom: 10px;"><?php echo e($cat['name']); ?></h3>
            <p style="color: var(--gray-dark); font-size: 14px;"><?php echo e($cat['description']); ?></p>
            <span style="display: inline-block; margin-top: 20px; color: var(--amber); font-weight: 700;">Explore Products <i class="fas fa-arrow-right"></i></span>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
