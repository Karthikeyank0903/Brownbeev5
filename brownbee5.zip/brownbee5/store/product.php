<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$slug = $_GET['slug'] ?? '';

if (!$slug) {
    redirect('products.php');
}

// Fetch product details
$stmt = $pdo->prepare("
    SELECT p.*, c.name as category_name, c.slug as category_slug, u.full_name as vendor_name, vp.store_name
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    JOIN users u ON p.vendor_id = u.id
    JOIN vendor_profiles vp ON u.id = vp.user_id
    WHERE p.slug = ? AND p.status = 'published'
");
$stmt->execute([$slug]);
$product = $stmt->fetch();

if (!$product) {
    redirect('products.php');
}

$page_title = $product['name'];
require_once '../includes/header.php';

// Fetch product images
$stmt = $pdo->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order ASC");
$stmt->execute([$product['id']]);
$images = $stmt->fetchAll();

// Dietary tags array
$dietary_tags = $product['dietary_tags'] ? explode(',', $product['dietary_tags']) : [];
?>

<div class="container" style="padding: 60px 0;">
    <div style="display: flex; gap: 60px; align-items: flex-start;">
        <!-- Product Images -->
        <div style="flex: 1;">
            <div style="background: var(--gray-light); border-radius: var(--radius-lg); overflow: hidden; margin-bottom: 20px;">
                <img src="<?php echo BASE_URL; ?>uploads/products/placeholder.jpg" alt="<?php echo e($product['name']); ?>" style="width: 100%; height: auto;">
            </div>
            <?php if (!empty($images)): ?>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px;">
                <?php foreach ($images as $img): ?>
                <div style="border: 1px solid var(--gray-light); border-radius: var(--radius-sm); overflow: hidden; cursor: pointer;">
                    <img src="<?php echo BASE_URL . $img['image_path']; ?>" style="width: 100%; height: 80px; object-fit: cover;">
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Product Info -->
        <div style="flex: 1;">
            <div style="margin-bottom: 20px;">
                <a href="category.php?slug=<?php echo $product['category_slug']; ?>" style="color: var(--amber); font-weight: 700; text-transform: uppercase; font-size: 14px;"><?php echo e($product['category_name']); ?></a>
                <h1 style="font-size: 36px; margin: 10px 0;"><?php echo e($product['name']); ?></h1>
                
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
                    <span style="font-size: 28px; font-weight: 700; color: var(--brown);"><?php echo format_currency($product['sale_price'] ?? $product['base_price']); ?></span>
                    <?php if ($product['sale_price']): ?>
                        <span style="text-decoration: line-through; color: var(--gray-dark);"><?php echo format_currency($product['base_price']); ?></span>
                    <?php endif; ?>
                </div>

                <div style="display: flex; gap: 10px; margin-bottom: 30px;">
                    <span style="background: var(--leaf-green); color: white; padding: 4px 12px; border-radius: 4px; font-size: 12px; font-weight: 600;">100% ORGANIC</span>
                    <?php foreach ($dietary_tags as $tag): ?>
                        <span style="background: var(--cream); color: var(--brown); padding: 4px 12px; border-radius: 4px; font-size: 12px; font-weight: 600; border: 1px solid rgba(59, 31, 10, 0.1);"><?php echo strtoupper(trim($tag)); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>

            <div style="padding: 25px; background: var(--gray-light); border-radius: var(--radius-md); margin-bottom: 30px;">
                <p style="color: var(--gray-dark); margin-bottom: 20px; line-height: 1.8;"><?php echo nl2br(e($product['description'])); ?></p>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <div style="display: flex; align-items: center; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); background: white;">
                        <button style="padding: 10px 15px; border: none; background: none; cursor: pointer;">-</button>
                        <input type="number" value="1" style="width: 50px; text-align: center; border: none; outline: none; font-weight: 700;">
                        <button style="padding: 10px 15px; border: none; background: none; cursor: pointer;">+</button>
                    </div>
                    <button class="btn btn-primary" style="flex: 1;" onclick="addToCart(<?php echo $product['id']; ?>)">Add to Basket</button>
                </div>
            </div>

            <div style="border-top: 1px solid var(--gray-light); padding-top: 25px;">
                <p style="font-size: 14px; color: var(--gray-dark);">
                    <i class="fas fa-store" style="margin-right: 8px; color: var(--amber);"></i> 
                    Sold by: <a href="vendor.php?id=<?php echo $product['vendor_id']; ?>" style="font-weight: 700; color: var(--brown);"><?php echo e($product['store_name']); ?></a>
                </p>
                <p style="font-size: 14px; color: var(--gray-dark); margin-top: 10px;">
                    <i class="fas fa-truck" style="margin-right: 8px; color: var(--leaf-green);"></i> 
                    Standard Delivery: Within 24-48 hours
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
