<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Auth Check
if (!is_logged_in()) {
    redirect(BASE_URL . 'login.php');
}

$page_title = "My Dashboard";
require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];

// Fetch recent orders
$stmt = $pdo->prepare("SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC LIMIT 3");
$stmt->execute([$user_id]);
$recent_orders = $stmt->fetchAll();

// Stats
$order_count = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE customer_id = ?");
$order_count->execute([$user_id]);
$total_orders = $order_count->fetchColumn();

$wishlist_count = $pdo->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = ?");
$wishlist_count->execute([$user_id]);
$total_wishlist = $wishlist_count->fetchColumn();
?>

<div class="container" style="padding: 60px 0;">
    <div style="display: flex; gap: 40px;">
        <!-- Sidebar -->
        <aside style="width: 250px;">
            <div style="background: var(--white); border-radius: var(--radius-md); border: 1px solid var(--gray-light); padding: 20px;">
                <h3 style="margin-bottom: 20px;">My Account</h3>
                <ul class="footer-links" style="color: var(--black);">
                    <li><a href="dashboard.php" style="font-weight: 700; color: var(--amber);"><i class="fas fa-th-large" style="margin-right: 10px;"></i> Dashboard</a></li>
                    <li><a href="orders.php"><i class="fas fa-shopping-bag" style="margin-right: 10px;"></i> My Orders</a></li>
                    <li><a href="wishlist.php"><i class="fas fa-heart" style="margin-right: 10px;"></i> Wishlist</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-edit" style="margin-right: 10px;"></i> Profile Settings</a></li>
                    <li><a href="../logout.php" style="color: #b91c1c;"><i class="fas fa-sign-out-alt" style="margin-right: 10px;"></i> Logout</a></li>
                </ul>
            </div>
        </aside>

        <!-- Content -->
        <div style="flex: 1;">
            <div style="margin-bottom: 40px;">
                <h2 style="margin-bottom: 10px;">Hello, <?php echo e($_SESSION['full_name']); ?>!</h2>
                <p style="color: var(--gray-dark);">From your account dashboard you can view your recent orders, manage your shipping addresses, and edit your password and account details.</p>
            </div>

            <!-- Stats Grid -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 40px;">
                <div style="background: var(--cream); padding: 30px; border-radius: var(--radius-md); text-align: center; border: 1px solid rgba(186, 117, 23, 0.2);">
                    <i class="fas fa-shopping-basket" style="font-size: 32px; color: var(--amber); margin-bottom: 15px;"></i>
                    <h3 style="font-size: 28px;"><?php echo $total_orders; ?></h3>
                    <p style="color: var(--gray-dark); font-weight: 600;">Total Orders</p>
                </div>
                <div style="background: #f1f5f9; padding: 30px; border-radius: var(--radius-md); text-align: center; border: 1px solid #e2e8f0;">
                    <i class="fas fa-heart" style="font-size: 32px; color: #64748b; margin-bottom: 15px;"></i>
                    <h3 style="font-size: 28px;"><?php echo $total_wishlist; ?></h3>
                    <p style="color: var(--gray-dark); font-weight: 600;">Wishlist Items</p>
                </div>
            </div>

            <!-- Recent Orders Card -->
            <div style="background: var(--white); border-radius: var(--radius-md); border: 1px solid var(--gray-light); overflow: hidden;">
                <div style="padding: 20px 25px; border-bottom: 1px solid var(--gray-light); display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="font-size: 18px;">Recent Orders</h3>
                    <a href="orders.php" style="color: var(--amber); font-size: 14px; font-weight: 600;">View All</a>
                </div>
                <div style="padding: 0;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead style="background: #fafafa;">
                            <tr>
                                <th style="text-align: left; padding: 15px 25px; font-size: 14px; color: var(--gray-dark);">Order ID</th>
                                <th style="text-align: left; padding: 15px 25px; font-size: 14px; color: var(--gray-dark);">Date</th>
                                <th style="text-align: left; padding: 15px 25px; font-size: 14px; color: var(--gray-dark);">Total</th>
                                <th style="text-align: left; padding: 15px 25px; font-size: 14px; color: var(--gray-dark);">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_orders as $order): ?>
                            <tr>
                                <td style="padding: 15px 25px; border-top: 1px solid var(--gray-light); font-size: 14px;">#<?php echo $order['id']; ?></td>
                                <td style="padding: 15px 25px; border-top: 1px solid var(--gray-light); font-size: 14px;"><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                <td style="padding: 15px 25px; border-top: 1px solid var(--gray-light); font-size: 14px;"><?php echo format_currency($order['grand_total']); ?></td>
                                <td style="padding: 15px 25px; border-top: 1px solid var(--gray-light); font-size: 14px;">
                                    <span style="padding: 4px 10px; border-radius: 99px; font-size: 12px; font-weight: 600; background: #dcfce7; color: #166534;">
                                        <?php echo ucfirst($order['order_status']); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($recent_orders)): ?>
                            <tr><td colspan="4" style="text-align: center; padding: 30px; color: var(--gray-dark);">No orders placed yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
