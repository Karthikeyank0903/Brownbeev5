<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Auth Check
if (!is_logged_in()) {
    redirect(BASE_URL . 'login.php');
}

$page_title = "My Wishlist";
require_once '../includes/header.php';

// Fetch wishlist items
$stmt = $pdo->prepare("
    SELECT p.*, c.name as category_name 
    FROM wishlist w 
    JOIN products p ON w.product_id = p.id 
    JOIN categories c ON p.category_id = c.id 
    WHERE w.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$wishlist_items = $stmt->fetchAll();
?>

<div class="container" style="padding: 60px 0;">
    <div style="display: flex; gap: 40px;">
        <!-- Sidebar -->
        <aside style="width: 250px;">
            <div style="background: var(--white); border-radius: var(--radius-md); border: 1px solid var(--gray-light); padding: 20px;">
                <h3 style="margin-bottom: 20px;">My Account</h3>
                <ul class="footer-links" style="color: var(--black);">
                    <li><a href="dashboard.php"><i class="fas fa-th-large" style="margin-right: 10px;"></i> Dashboard</a></li>
                    <li><a href="orders.php"><i class="fas fa-shopping-bag" style="margin-right: 10px;"></i> My Orders</a></li>
                    <li><a href="wishlist.php" style="font-weight: 700; color: var(--amber);"><i class="fas fa-heart" style="margin-right: 10px;"></i> Wishlist</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-edit" style="margin-right: 10px;"></i> Profile Settings</a></li>
                    <li><a href="../logout.php" style="color: #b91c1c;"><i class="fas fa-sign-out-alt" style="margin-right: 10px;"></i> Logout</a></li>
                </ul>
            </div>
        </aside>

        <!-- Content -->
        <div style="flex: 1;">
            <h2 style="margin-bottom: 30px;">My Wishlist</h2>

            <?php if (empty($wishlist_items)): ?>
                <div style="text-align: center; padding: 60px; background: var(--gray-light); border-radius: var(--radius-md);">
                    <i class="far fa-heart" style="font-size: 48px; color: var(--gray-medium); margin-bottom: 20px;"></i>
                    <h3>Your wishlist is empty</h3>
                    <p>Save items you like to see them here later.</p>
                    <a href="../store/products.php" class="btn btn-secondary" style="margin-top: 20px;">Browse Products</a>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php foreach ($wishlist_items as $product): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <img src="<?php echo BASE_URL; ?>uploads/products/placeholder.jpg" alt="<?php echo e($product['name']); ?>">
                        </div>
                        <div class="product-info">
                            <span class="product-cat"><?php echo e($product['category_name']); ?></span>
                            <a href="../store/product.php?slug=<?php echo $product['slug']; ?>" class="product-name"><?php echo e($product['name']); ?></a>
                            <div class="product-price">
                                <span class="price-current"><?php echo format_currency($product['sale_price'] ?? $product['base_price']); ?></span>
                            </div>
                            <div class="product-actions">
                                <button class="btn btn-primary" style="flex: 1; padding: 10px;" onclick="addToCart(<?php echo $product['id']; ?>)">
                                    Add to Basket
                                </button>
                                <button class="btn btn-outline" style="padding: 10px;" title="Remove from wishlist">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
