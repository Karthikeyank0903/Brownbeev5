<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Auth Check
if (!is_logged_in()) {
    redirect(BASE_URL . 'login.php');
}

$page_title = "My Orders";
require_once '../includes/header.php';

$stmt = $pdo->prepare("SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();
?>

<div class="container" style="padding: 60px 0;">
    <div style="display: flex; gap: 40px;">
        <!-- Sidebar -->
        <aside style="width: 250px;">
            <div style="background: var(--white); border-radius: var(--radius-md); border: 1px solid var(--gray-light); padding: 20px;">
                <h3 style="margin-bottom: 20px;">My Account</h3>
                <ul class="footer-links" style="color: var(--black);">
                    <li><a href="dashboard.php"><i class="fas fa-th-large" style="margin-right: 10px;"></i> Dashboard</a></li>
                    <li><a href="orders.php" style="font-weight: 700; color: var(--amber);"><i class="fas fa-shopping-bag" style="margin-right: 10px;"></i> My Orders</a></li>
                    <li><a href="wishlist.php"><i class="fas fa-heart" style="margin-right: 10px;"></i> Wishlist</a></li>
                    <li><a href="profile.php"><i class="fas fa-user-edit" style="margin-right: 10px;"></i> Profile Settings</a></li>
                    <li><a href="../logout.php" style="color: #b91c1c;"><i class="fas fa-sign-out-alt" style="margin-right: 10px;"></i> Logout</a></li>
                </ul>
            </div>
        </aside>

        <!-- Content -->
        <div style="flex: 1;">
            <h2 style="margin-bottom: 30px;">Order History</h2>

            <?php if (empty($orders)): ?>
                <div style="text-align: center; padding: 60px; background: var(--gray-light); border-radius: var(--radius-md);">
                    <i class="fas fa-box-open" style="font-size: 48px; color: var(--gray-medium); margin-bottom: 20px;"></i>
                    <h3>You haven't placed any orders yet</h3>
                    <p>When you buy something, you'll see your order details here.</p>
                    <a href="../store/products.php" class="btn btn-secondary" style="margin-top: 20px;">Shop Now</a>
                </div>
            <?php else: ?>
                <div style="background: var(--white); border-radius: var(--radius-md); border: 1px solid var(--gray-light); overflow: hidden;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead style="background: #fafafa;">
                            <tr>
                                <th style="text-align: left; padding: 15px 25px;">Order ID</th>
                                <th style="text-align: left; padding: 15px 25px;">Date</th>
                                <th style="text-align: left; padding: 15px 25px;">Total</th>
                                <th style="text-align: left; padding: 15px 25px;">Status</th>
                                <th style="text-align: left; padding: 15px 25px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                            <tr>
                                <td style="padding: 20px 25px; border-top: 1px solid var(--gray-light);">#<?php echo $order['id']; ?></td>
                                <td style="padding: 20px 25px; border-top: 1px solid var(--gray-light);"><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                <td style="padding: 20px 25px; border-top: 1px solid var(--gray-light);"><?php echo format_currency($order['grand_total']); ?></td>
                                <td style="padding: 20px 25px; border-top: 1px solid var(--gray-light);">
                                    <span style="padding: 4px 10px; border-radius: 99px; font-size: 12px; font-weight: 600; background: #dcfce7; color: #166534;">
                                        <?php echo ucfirst($order['order_status']); ?>
                                    </span>
                                </td>
                                <td style="padding: 20px 25px; border-top: 1px solid var(--gray-light);">
                                    <a href="order-details.php?id=<?php echo $order['id']; ?>" class="btn btn-outline" style="padding: 5px 15px; font-size: 13px;">View Details</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
