<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Auth Check
if (!is_logged_in()) {
    redirect(BASE_URL . 'login.php');
}

$page_title = "My Profile";
require_once '../includes/header.php';

$user = get_current_user_data($pdo);
?>

<div class="container" style="padding: 60px 0;">
    <div style="display: flex; gap: 40px;">
        <!-- Sidebar -->
        <aside style="width: 250px;">
            <div style="background: var(--white); border-radius: var(--radius-md); border: 1px solid var(--gray-light); padding: 20px;">
                <h3 style="margin-bottom: 20px;">My Account</h3>
                <ul class="footer-links" style="color: var(--black);">
                    <li><a href="dashboard.php"><i class="fas fa-th-large" style="margin-right: 10px;"></i> Dashboard</a></li>
                    <li><a href="orders.php"><i class="fas fa-shopping-bag" style="margin-right: 10px;"></i> My Orders</a></li>
                    <li><a href="wishlist.php"><i class="fas fa-heart" style="margin-right: 10px;"></i> Wishlist</a></li>
                    <li><a href="profile.php" style="font-weight: 700; color: var(--amber);"><i class="fas fa-user-edit" style="margin-right: 10px;"></i> Profile Settings</a></li>
                    <li><a href="../logout.php" style="color: #b91c1c;"><i class="fas fa-sign-out-alt" style="margin-right: 10px;"></i> Logout</a></li>
                </ul>
            </div>
        </aside>

        <!-- Content -->
        <div style="flex: 1;">
            <div style="background: var(--white); border-radius: var(--radius-md); border: 1px solid var(--gray-light); padding: 40px;">
                <h2 style="margin-bottom: 30px;">Profile Settings</h2>
                
                <form action="profile.php" method="POST">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 25px;">
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-weight: 600;">Full Name</label>
                            <input type="text" name="full_name" value="<?php echo e($user['full_name']); ?>" style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md);">
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-weight: 600;">Email Address</label>
                            <input type="email" value="<?php echo e($user['email']); ?>" disabled style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md); background: #f9f9f9; cursor: not-allowed;">
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 25px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600;">Phone Number</label>
                        <input type="text" name="phone" value="<?php echo e($user['phone']); ?>" style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md);">
                    </div>

                    <hr style="margin: 40px 0; border: none; border-top: 1px solid var(--gray-light);">
                    
                    <h3 style="margin-bottom: 20px;">Change Password</h3>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 30px;">
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-weight: 600;">New Password</label>
                            <input type="password" name="new_password" placeholder="Leave blank to keep current" style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md);">
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 8px; font-weight: 600;">Confirm Password</label>
                            <input type="password" name="confirm_password" placeholder="Confirm new password" style="width: 100%; padding: 12px; border: 1px solid var(--gray-medium); border-radius: var(--radius-md);">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-secondary">Update Profile</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
