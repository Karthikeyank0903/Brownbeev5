<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$page_title = "Pure. Natural. Delivered.";
require_once 'includes/header.php';

// Fetch Categories
$categories = $pdo->query("SELECT * FROM categories WHERE status = 'active' LIMIT 6")->fetchAll();

// Fetch Featured Products
$featured = $pdo->query("SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.status = 'published' ORDER BY p.created_at DESC LIMIT 8")->fetchAll();
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container" style="display: flex; align-items: center; gap: 60px;">
        <div class="hero-content" style="flex: 1.2;">
            <span class="hero-subtitle">100% Organic Certified</span>
            <h1>Fresh, Organic <br><span>Nature's Best</span></h1>
            <p>From the heart of the farm to your doorstep. Experience the purity of 100% organic food harvested with love.</p>
            <div class="hero-btns" style="display: flex; gap: 15px; margin-top: 30px;">
                <a href="store/products.php" class="btn btn-primary" style="padding: 15px 35px;">Shop Now</a>
                <a href="vendor-apply.php" class="btn btn-secondary" style="padding: 15px 35px;">Sell with Us</a>
            </div>
        </div>
        <div class="hero-image" style="flex: 1;">
            <img src="assets/images/hero-organic.png" alt="Fresh Organic Harvest" style="width: 100%; border-radius: var(--radius-lg); box-shadow: var(--shadow-lg);">
        </div>
    </div>
</section>

<!-- Categories Grid -->
<section class="categories-section section-padding">
    <div class="container">
        <div class="section-header">
            <h2>Shop by Category</h2>
            <p>Handpicked fresh produce in every category</p>
        </div>
        
        <div class="categories-grid">
            <?php foreach ($categories as $cat): ?>
            <a href="store/category.php?slug=<?php echo $cat['slug']; ?>" class="category-card">
                <div class="category-icon">
                    <i class="fas fa-shopping-basket"></i>
                </div>
                <h3><?php echo e($cat['name']); ?></h3>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Products -->
<section class="featured-products section-padding">
    <div class="container">
        <div class="section-header">
            <h2>New Arrivals</h2>
            <p>Recently harvested organic goodness</p>
        </div>

        <div class="products-grid">
            <?php foreach ($featured as $product): ?>
            <div class="product-card">
                <span class="product-badge">Organic</span>
                <div class="product-wishlist"><i class="far fa-heart"></i></div>
                <div class="product-image">
                    <!-- Placeholder image -->
                    <img src="uploads/products/placeholder.jpg" alt="<?php echo e($product['name']); ?>">
                </div>
                <div class="product-info">
                    <span class="product-cat"><?php echo e($product['category_name']); ?></span>
                    <a href="store/product.php?slug=<?php echo $product['slug']; ?>" class="product-name"><?php echo e($product['name']); ?></a>
                    <div class="product-price">
                        <span class="price-current"><?php echo format_currency($product['sale_price'] ?? $product['base_price']); ?></span>
                        <?php if ($product['sale_price']): ?>
                            <span class="price-old"><?php echo format_currency($product['base_price']); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="product-actions">
                        <button class="btn btn-primary" onclick="addToCart(<?php echo $product['id']; ?>)">Add to Basket</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
