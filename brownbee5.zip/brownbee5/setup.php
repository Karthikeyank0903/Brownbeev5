<?php
// setup.php - Database initialization script

require_once 'config.php';

try {
    // Connect without database selected to create it if it doesn't exist
    $dsn = "mysql:host=" . DB_HOST;
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME);
    $pdo->exec("USE " . DB_NAME);

    // Read and execute database.sql
    $sql = file_get_contents('database.sql');
    $pdo->exec($sql);
    echo "Database and tables created successfully.<br>";

    // Check if admin already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
    $stmt->execute();
    $adminCount = $stmt->fetchColumn();

    if ($adminCount == 0) {
        // Seed Super Admin
        $adminEmail = ADMIN_EMAIL;
        $adminPass = password_hash(ADMIN_PASS, PASSWORD_BCRYPT, ['cost' => 12]);
        $fullName = "Super Admin";

        $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, status) VALUES (?, ?, ?, 'admin', 'active')");
        $stmt->execute([$fullName, $adminEmail, $adminPass]);
        echo "Super Admin account created: $adminEmail<br>";
    } else {
        echo "Admin account already exists.<br>";
    }

    echo "Setup complete. Please delete setup.php for security reasons.<br>";
    
    // Uncomment the line below to auto-delete
    // unlink(__FILE__);

} catch (PDOException $e) {
    die("Setup failed: " . $e->getMessage());
}
?>
